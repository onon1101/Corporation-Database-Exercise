using Microsoft.Net.Http.Headers;

public class UserLoginEmailOrUname
{
    public string Value { get; set; }
    public string Password { get; set; }
}