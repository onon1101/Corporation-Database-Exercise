namespace MyRestApi.DTO
{
    public class UsernameLoginDTO
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}