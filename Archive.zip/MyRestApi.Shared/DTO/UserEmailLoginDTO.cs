namespace MyRestApi.DTO
{
    public class UserEmailLoginDTO
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}