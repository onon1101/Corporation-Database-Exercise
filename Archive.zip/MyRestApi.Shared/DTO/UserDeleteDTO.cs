public class UserDeleteDTO
{
    public Guid Id { get; set; }
}