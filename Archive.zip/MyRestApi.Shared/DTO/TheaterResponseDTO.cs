public class TheaterResponseDTO
{
    public Guid id;
}