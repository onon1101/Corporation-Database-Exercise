﻿namespace MyRestApi.Shared;

public class Class1
{

}
