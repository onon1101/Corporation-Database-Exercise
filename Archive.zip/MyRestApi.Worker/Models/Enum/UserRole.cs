public enum UserRole
{
    GUEST = 0,
    USER,
    ADMIN,
}