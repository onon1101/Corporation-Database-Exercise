namespace MyRestApi.Models
{
    public enum ReservationStatus
    {
        Pending,
        Paid,
        Cancelled
    }
}